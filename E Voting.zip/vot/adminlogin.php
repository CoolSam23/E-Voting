<?php
echo"hi2";
   // connect to mongodb
   $m = new MongoClient();
   $db = $m->voting;
   
   $collection = $db->admin;
 
  $name=$_POST['name'];
  $password=$_POST['password'];
 
  $user = $collection->find(array("name"=>$name,"password"=>$password));   
    foreach($user as $document)	
	$var=$document['name'];
      
	  if($var==$name)
	    {
	      header("Location:vadmin.html");
	    }    
	  else
	    {
	      header("Location:vhome.html");
	    }
   
?>

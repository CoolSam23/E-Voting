<?php

  
   $m = new MongoClient();
   
   $db = $m->voting;
   
   $collection = $db->candidate;
     $user = $db->result;

  $y="yes";

$sam = $user->findOne(array('declared' =>$y )); 
if($sam)
{

echo"result is declared <br>";
    echo "<table>
  <tr>
  <th>candidate_Id</th>
  <th>candidate_Name</th>
  <th>candidate_party</th>
   <th>candidate_votes</th>
  </tr>";
  
  $cursor=$collection->find(array());
 
   foreach($cursor as $document)
   {
            echo "<tr>
   <td>".$document['candidate_id']."</td>
   <td>".$document['candidate_name']."</td>
     <td>".$document['candidate_party']."</td>
    <td>".$document['candidate_votes']."</td>
   </tr>";
  }
  echo "</table>";
 }
 else
{
 echo"result is not declared";
}  
   echo " <br><a href='vhome.html'>BACK</a>";
?>

<html>
<head>

<style>

table {

    width: 100%;
    border-color:red;
    border-width:2px;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>
</head>
</html>


<?php

 
	$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->admin;
   
	$name = $_POST['name'];
    $password = $_POST['password'];
   
  $document = array( 
      "name" =>"$name", 
      "password" =>"$password", 
      
   );
	
   if($collection->insert($document))
   echo "Document inserted successfully";

    ?>
	<html>
	<head>
	<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>

</head>
</html>







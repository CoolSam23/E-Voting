<?php

  session_start();
   $m = new MongoClient();
   
   $db = $m->voting;
   
   $collection = $db->voter;
  
    echo "<table>
  <tr>
  <th>Voter_Id</th>
  <th>Voter_Name</th>
  <th>Voter_Address</th>
  <th>Voter_Dob</th>
  <th>Gender</th>
  </tr>";
  
  $cursor=$collection->find(array());
 
   foreach($cursor as $document)
   {
            echo "<tr>
   <td>".$document['voter_id']."</td>
   <td>".$document['voter_name']."</td>
   <td>".$document['voter_address']."</td>
   <td>".$document['voter_dob']."</td>
   <td>".$document['gender']."</td>
   </tr>";
  }
  echo "</table>";
   
   echo " <br><a href='vadmin.html'>BACK</a>";
?>

<html>
<head>

<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>
</head>
</html>

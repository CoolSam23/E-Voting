<?php

  session_start();
   $m = new MongoClient();
   
   $db = $m->voting;
   
   $collection = $db->candidate;
  
    echo "<table border='2' color='silver'align='center'>
  <tr>
  <th>candidate_Id</th>
  <th>candidate_Name</th>
  <th>candidate_Address</th>
  <th>candidate_Dob</th>
  <th>Gender</th>
  <th>candidate_party</th>
   <th>candidate_votes</th>
  </tr>";
  
  $cursor=$collection->find(array());
 
   foreach($cursor as $document)
   {
            echo "<tr>
   <td>".$document['candidate_id']."</td>
   <td>".$document['candidate_name']."</td>
   <td>".$document['candidate_address']."</td>
   <td>".$document['candidate_dob']."</td>
   <td>".$document['gender']."</td>
     <td>".$document['candidate_party']."</td>
   <td>".$document['candidate_votes']."</td>
      
</tr>";
  }
  echo "</table>";
   
   echo " <br><a href='vadmin.html'>BACK</a>";
?>

<html>
<head>

<style>

table {
    border-collapse: collapse;
    width: 80%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>
</head>
</html>

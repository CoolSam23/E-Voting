<?php

$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->candidate;

   $candidate_id = $_POST['candidate_id'];
	$candidate_id1 = $_POST['candidate_id1'];
    $candidate_name = $_POST['candidate_name'];
         $candidate_address = $_POST['candidate_address'];
       $candidate_dob = $_POST['candidate_dob'];
       $gender = $_POST['gender'];
       $candidate_party = $_POST['candidate_party'];

$collection->update(array("candidate_id"=>$candidate_id),array('$set'=>array("candidate_id"=>$candidate_id1,"candidate_name"=>$candidate_name,"candidate_address"=>$candidate_address,"candidate_dob"=>$candidate_dob,"gender"=>$gender,"candidate_party"=>$candidate_party)));

echo "candidate updated successfully";
   
echo " <br><a href='vadmin.html'>BACK</a>";
    ?>
	<html>
	<head>
	<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>

</head>
</html>


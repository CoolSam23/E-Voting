<?PHP

	$m =  new MongoClient();
   
	$db = $m->voting;
   
	$users = $db->voter;
         $users1 = $db->candidate;
$selected = $_POST['gender'];
$selecte="male";
if($selected=="male")
{

 echo "<table>
  <tr>
  <th>candidate_Id</th>
  <th>candidate_Name</th>
  <th>candidate_Address</th>
  <th>candidate_Dob</th>
  <th>Gender</th>
  <th>candidate_party</th>
  </tr>";
  
  $cursor=$users1->find(array());
 
   foreach($cursor as $document)
   {
            echo "<tr>
   <td>".$document['candidate_id']."</td>
   <td>".$document['candidate_name']."</td>
   <td>".$document['candidate_address']."</td>
   <td>".$document['candidate_dob']."</td>
   <td>".$document['gender']."</td>
     <td>".$document['candidate_party']."</td>
   </tr>";
  }
  echo "</table>";
   
}
echo " <br><a href='vadmin.html'>BACK</a>";

?>

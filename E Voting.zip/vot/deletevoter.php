<?php

$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->voter;

   $voter_id = $_POST['voter_id'];

$collection->remove(array("voter_id"=>$voter_id));

echo "Voter Deleted successfully";
   
echo " <br><a href='vadmin.html'>BACK</a>";
   
?>

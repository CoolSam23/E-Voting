<?php
 
	$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->result;
   
	$declared = $_POST['gender'];
         $y="yes";
         $n="no";
     
  //$document = array( 
    //      "declared" =>$declared, 
  // );
	
//   if($collection->insert($document))
$collection->update(array("declared"=>"no"),array('$set'=> array("declared"=>$declared)));
$collection->update(array("declared"=>"yes"),array('$set'=> array("declared"=>$declared)));

if($declared==$y)
echo "result declared successfully";
   

if($declared==$n)
echo "result hide successfully";
   
echo " <br><a href='vadmin.html'>BACK</a>";
    ?>
	<html>
	<head>
	<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>

</head>
</html>


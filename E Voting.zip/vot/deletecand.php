<?php

$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->candidate;

   $candidate_id = $_POST['candidate_id'];

$collection->remove(array("candidate_id"=>$candidate_id));

echo "candidate Deleted successfully";
   
echo " <br><a href='vadmin.html'>BACK</a>";
   
?>

<?php
 
	$m =  new MongoClient();
   
	$db = $m->voting;
   
	$collection = $db->voter;
   
	$voter_id = $_POST['voter_id'];
    $voter_name = $_POST['voter_name'];
         $voter_address = $_POST['voter_address'];
       $voter_dob = $_POST['voter_dob'];
       $gender = $_POST['gender'];   
  $document = array( 
      "voter_id" =>"$voter_id", 
      "voter_name" =>"$voter_name", 
       "voter_address" =>"$voter_address", 
      "voter_dob" =>"$voter_dob", 
      "gender" =>"$gender", 
      
   );
	
   if($collection->insert($document))

echo "Voter registered successfully";
   
echo " <br><a href='vadmin.html'>BACK</a>";
    ?>
	<html>
	<head>
	<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color:lightblue;
    color: black;
}
#form1
 {	
   position:absolute;
   top:500px;
   left:550px;
 }
#button1
 { 
   background-color:lightblue;
   color:black;
   border:2px solid lightblue;
   height:50px;
   width:200;
 }
#button1:hover
 {
   background-color:blue;
   color:white;
 } 

</style>

</head>
</html>


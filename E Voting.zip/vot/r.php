<?PHP



	$m =  new MongoClient();
   
	$db = $m->voting;
   
	$users = $db->voter;
         $users1 = $db->candidate;
$selected = $_POST['gender'];
$voter_id = $_POST['voter_id'];
$add=1;

$user = $users->findOne(array('voter_id' =>$voter_id )); 
if($user==NULL)
echo"You  are not valid voter";

if($user!=NULL)
{

  print "voter id:$voter_id<br>";
   print"you choose:$selected<br>";

 $cursor=$users1->find(array("candidate_name"=>"$selected"));
 
   foreach($cursor as $document)
   {
     $orgamount=$document['candidate_votes'];
   }
   $newamount=$orgamount+$add;
   
   $criteria=array("candidate_name"=>"$selected");
   $newdata=array('$set'=>array("candidate_votes"=>"$newamount"));
    
   $result=$users1->update($criteria,$newdata);
   echo "vote successfully";
 
}

   
echo " <br><a href='vhome.html'>BACK</a>";

?>
